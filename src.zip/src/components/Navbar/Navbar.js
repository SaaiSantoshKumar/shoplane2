import "./Navbar.css";
import { NavLink } from "react-router-dom";
import Badge from 'react-bootstrap/Badge';

const Navbar = () => {
  return (
<div>
<span className="c">  
<div className="nav d-flex flex-row">
  
    <nav>
            <div className="logo p-2">
            <NavLink to="/">
            <p id="L1">SHOP</p><p id="L2">LANE</p>
            </NavLink>
            </div>
        </nav>
    
    <div className="parent p-2">
    <div className="child inline-block-child">
    <div className="dropdown">
      <button className="dropbtn"><svg xmlns="http://www.w3.org/2000/svg" width="25px" height="25px" fill="currentColor" className="bi bi-person" viewBox="0 0 16 16">
            <path d="M8 8a3 3 0 1 0 0-6 3 3 0 0 0 0 6Zm2-3a2 2 0 1 1-4 0 2 2 0 0 1 4 0Zm4 8c0 1-1 1-1 1H3s-1 0-1-1 1-4 6-4 6 3 6 4Zm-1-.004c-.001-.246-.154-.986-.832-1.664C11.516 10.68 10.289 10 8 10c-2.29 0-3.516.68-4.168 1.332-.678.678-.83 1.418-.832 1.664h10Z"/>
            </svg> Login or Signup</button>
      <div className="dropdown-content">
        <a href="/login" >Login</a>
        <a href="/signup" >Sign up</a>
        <a href="/cart" >Cart</a>
      </div>
    </div>

    </div>
    <div className="child inline-block-child">
    <NavLink to="/cart" ><svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="currentColor" className="bi bi-cart3" viewBox="0 0 16 16">
                <path d="M0 1.5A.5.5 0 0 1 .5 1H2a.5.5 0 0 1 .485.379L2.89 3H14.5a.5.5 0 0 1 .49.598l-1 5a.5.5 0 0 1-.465.401l-9.397.472L4.415 11H13a.5.5 0 0 1 0 1H4a.5.5 0 0 1-.491-.408L2.01 3.607 1.61 2H.5a.5.5 0 0 1-.5-.5zM3.102 4l.84 4.479 9.144-.459L13.89 4H3.102zM5 12a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm7 0a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm-7 1a1 1 0 1 1 0 2 1 1 0 0 1 0-2zm7 0a1 1 0 1 1 0 2 1 1 0 0 1 0-2z"/>
                </svg></NavLink>
            <Badge>{2}</Badge>
            </div>
    </div>
      
  </div>
  </span>
<span className="c">
<hr/>0
  <div className="menuitems navbar navbar-expand-lg justify-content-center">
  
    <ul className="navbar-nav justify-content-around">
    <li className="nav-item">
    <NavLink className="nav-link text-secondary" to="/"> All</NavLink>
      
  </li>
  <li className="nav-item">
    <NavLink className="nav-link text-secondary" to="/electronics"> Electronics</NavLink>  
    </li>
  <li className="nav-item">
  <NavLink className="nav-link text-secondary" to="/jewel"> Jewelery</NavLink>  
  </li>
  <li className="nav-item">
  <NavLink className="nav-link text-secondary" to="/men"> Men's Colothing</NavLink>
  </li>
  <li className="nav-item">
  <NavLink className="nav-link text-secondary" to="/women"> Women's Colothing</NavLink>
  </li>
</ul>
    </div>
    <hr/>
    </span>
    </div>  
  );
};

export default Navbar;