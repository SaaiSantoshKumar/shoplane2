import React from 'react';
import logindetails from './logindetails.json';
import "./Login.css";



function Login({updateState}){
    
    //const {updateState} = undefined || {};
       //const{email,password}=formData;
    
    function handleSubmit(e)
    {
      e.preventDefault();
        if(e.target[0].value==='')
        {
          alert("Enter User Name ");
          
        }else if (e.target[1].value==='')
        {
          
          alert("Enter Password ");
        }
        else{
        if(e.target[0].value===logindetails.email)
        {
            if(e.target[1].value===logindetails.password)
            {
                console.log("Email & password Matching..... ");
                //updateState(true);
            }else{
                console.log("Password Not Matching...... ");
            }

        }else
        { 
            console.log("email Not Matching...... ");
        }
                
      }
    }


  return (
  <div className="login">  
      <div className="card1 border-light align-items-center">
        <div className="row g-0 d-flex">
        <div className="card-body py-5 px-md-5">
        <form  onSubmit={handleSubmit}>
        <h1 className="text-center text-secondary">Login</h1>
            <div className="form-outline align-items-center mb-4">
              <input type="email" id="email" placeholder="Email Address"></input>
          </div>
            <div className="form-outline mb-4">
              <input type="password" id="password" placeholder="Password"></input>
            </div>
              <div className="col"> Don't have an account? Sign up
             &nbsp;<a href="/signup">here</a>
              </div>
  <button type="submit" className="btn1 btn1-bd-primary"><h5><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" className="bi bi-box-arrow-in-right" viewBox="0 0 16 16">
  <path fillRule="evenodd" d="M6 3.5a.5.5 0 0 1 .5-.5h8a.5.5 0 0 1 .5.5v9a.5.5 0 0 1-.5.5h-8a.5.5 0 0 1-.5-.5v-2a.5.5 0 0 0-1 0v2A1.5 1.5 0 0 0 6.5 14h8a1.5 1.5 0 0 0 1.5-1.5v-9A1.5 1.5 0 0 0 14.5 2h-8A1.5 1.5 0 0 0 5 3.5v2a.5.5 0 0 0 1 0v-2z"/>
  <path fillRule="evenodd" d="M11.854 8.354a.5.5 0 0 0 0-.708l-3-3a.5.5 0 1 0-.708.708L10.293 7.5H1.5a.5.5 0 0 0 0 1h8.793l-2.147 2.146a.5.5 0 0 0 .708.708l3-3z"/>
  </svg>&nbsp;Login</h5></button>
          </form>
  </div>
</div>
</div>
    
  </div>

      
    );
}
  
export default Login;   